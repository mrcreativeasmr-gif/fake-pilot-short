// 3D World controller: sky shader, fog, sun lighting, and per-frame cast/camera updates
import * as THREE from "three";
import { buildWorld, Kit } from "./build";
import { Cast } from "./cast";
import { camAt, SHOTS } from "./story";
import { LIGHTS, LOOK } from "./lights";
import { TONE, CHAR, untone } from "./shade";

export class World {
  root = new THREE.Group();
  sun = new THREE.DirectionalLight(0xffffff, 1.5);
  amb = new THREE.AmbientLight(0xffffff, 0.5);
  skyMat: THREE.ShaderMaterial;
  cast: Cast;

  constructor(_kit: Kit) {
    buildWorld(this.root);
    this.cast = new Cast(this.root);

    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(1024, 1024);
    this.sun.shadow.camera.near = 1;
    this.sun.shadow.camera.far = 80;
    this.sun.shadow.camera.left = -22;
    this.sun.shadow.camera.right = 22;
    this.sun.shadow.camera.top = 22;
    this.sun.shadow.camera.bottom = -22;
    this.root.add(this.sun, this.sun.target, this.amb);

    this.skyMat = new THREE.ShaderMaterial({
      side: THREE.BackSide,
      depthWrite: false,
      uniforms: {
        uTop: { value: untone("#3e7fd2") },
        uHor: { value: untone("#b8d0ec") },
      },
      vertexShader: `varying vec3 vPos; void main() { vPos = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
      fragmentShader: `uniform vec3 uTop; uniform vec3 uHor; varying vec3 vPos;
        void main() {
          float h = clamp(normalize(vPos).y * 1.8, 0.0, 1.0);
          gl_FragColor = vec4(mix(uHor, uTop, pow(h, 0.75)), 1.0);
        }`,
    });
    const sky = new THREE.Mesh(new THREE.SphereGeometry(500, 16, 12), this.skyMat);
    this.root.add(sky);
  }

  update(id: number, f: number, cam: THREE.PerspectiveCamera, scene: THREE.Scene): THREE.Vector3 {
    const shot = SHOTS[id - 1];
    const preset = shot.light;
    const L = LIGHTS[preset];
    const K = LOOK[preset];

    const c = camAt(id, f);
    cam.position.set(c.pos[0], c.pos[1], c.pos[2]);
    cam.fov = c.fov;
    cam.updateProjectionMatrix();
    cam.lookAt(c.look[0], c.look[1], c.look[2]);
    cam.rotateZ(c.roll);

    // Camera-relative sun direction
    const fwd = new THREE.Vector3(c.look[0] - c.pos[0], 0, c.look[2] - c.pos[2]).normalize();
    const az = (L.az * Math.PI) / 180;
    const el = (L.el * Math.PI) / 180;
    const horiz = new THREE.Vector3(
      fwd.x * Math.cos(az) - fwd.z * Math.sin(az),
      0,
      fwd.x * Math.sin(az) + fwd.z * Math.cos(az)
    );
    const dir = new THREE.Vector3(
      horiz.x * Math.cos(el),
      Math.sin(el),
      horiz.z * Math.cos(el)
    ).normalize();

    this.sun.position.set(c.look[0] + dir.x * 30, c.look[1] + dir.y * 30, c.look[2] + dir.z * 30);
    this.sun.target.position.set(c.look[0], c.look[1], c.look[2]);
    this.sun.color.set(L.sunCol);
    this.sun.intensity = L.sunI;

    untone(L.top, this.skyMat.uniforms.uTop.value);
    untone(L.hor, this.skyMat.uniforms.uHor.value);
    scene.fog = new THREE.Fog(untone(L.fog), L.fogNear, L.fogFar);

    TONE.uLitCol.value.set(...L.lit);
    TONE.uShadeCol.value.set(...L.shade);
    TONE.uShadeLift.value.set(...L.lift);
    TONE.uLambert.value = L.lambert;
    TONE.uSideK.value = L.sideK;
    TONE.uTerm.value = L.term;
    TONE.uBounce.value.set(...K.bounce);
    TONE.uSat.value = K.sat;

    CHAR.uCharTint.value.set(...L.charTint);
    CHAR.uCharShade.value = L.charShade;
    CHAR.uGrad.value = L.charGrad;
    CHAR.uBodyGrad.value = L.bodyGrad;
    CHAR.uSideTint.value.set(...L.sideTint);

    this.cast.update(id, f, c.pos);
    return new THREE.Vector3(c.look[0], c.look[1], c.look[2]);
  }
}
