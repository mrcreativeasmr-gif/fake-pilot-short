// Timeline & Camera Grammar for "The Fake Pilot Who Flew 250 Flights for Free"
// Synced to ElevenLabs voiceover (words.json): 2305 frames @ 30 fps (76.83 s).
export const FPS = 30;
export const TOTAL = 2305;
export type V3 = [number, number, number];
export type Light = "day" | "golden";

export const clamp01 = (x: number) => Math.max(0, Math.min(1, x));
export const smooth = (x: number) => {
  const u = clamp01(x);
  return u * u * (3 - 2 * u);
};
export const glide = (u: number) => {
  const x = clamp01(u);
  return x * x * x * (x * (6 * x - 15) + 10);
};

export type SceneId =
  | "airport"
  | "bank"
  | "shop"
  | "workbench"
  | "gate"
  | "security"
  | "cockpit"
  | "hotel"
  | "paris"
  | "psychology"
  | "vest"
  | "archive"
  | "hollywood";

export type ShotDef = {
  id: number;
  a: number;
  b: number;
  light: Light;
  scene: SceneId;
  ox: number; // world X offset of this set
};

export const SHOTS: ShotDef[] = [
  { id: 1, a: 0, b: 180, light: "day", scene: "airport", ox: 0 },
  { id: 2, a: 180, b: 370, light: "day", scene: "bank", ox: 60 },
  { id: 3, a: 370, b: 578, light: "day", scene: "shop", ox: 120 },
  { id: 4, a: 578, b: 748, light: "day", scene: "workbench", ox: 180 },
  { id: 5, a: 748, b: 906, light: "day", scene: "gate", ox: 0 },
  { id: 6, a: 906, b: 1046, light: "day", scene: "security", ox: 0 },
  { id: 7, a: 1046, b: 1262, light: "golden", scene: "cockpit", ox: 240 },
  { id: 8, a: 1262, b: 1420, light: "golden", scene: "hotel", ox: 300 },
  { id: 9, a: 1420, b: 1570, light: "day", scene: "paris", ox: 360 },
  { id: 10, a: 1570, b: 1710, light: "golden", scene: "psychology", ox: 420 },
  { id: 11, a: 1710, b: 1940, light: "day", scene: "vest", ox: 480 },
  { id: 12, a: 1940, b: 2110, light: "day", scene: "archive", ox: 540 },
  { id: 13, a: 2110, b: TOTAL, light: "golden", scene: "hollywood", ox: 600 },
];

export const XFADE: Record<number, number> = {
  3: 6,
  4: 6,
  5: 6,
  7: 8,
  8: 8,
  9: 6,
  10: 8,
  11: 6,
  12: 6,
  13: 8,
};
export const FLASH_AT = 180;

export const shotAt = (f: number) =>
  SHOTS.find((s) => f >= s.a && f < s.b) ?? SHOTS[SHOTS.length - 1];

export const layersAt = (f: number): { id: number; alpha: number }[] => {
  for (const s of SHOTS) {
    const x = XFADE[s.id];
    if (x && f >= s.a - x / 2 && f < s.a + x / 2) {
      return [
        { id: s.id - 1, alpha: 1 },
        { id: s.id, alpha: (f - (s.a - x / 2) + 1) / (x + 1) },
      ];
    }
  }
  return [{ id: shotAt(f).id, alpha: 1 }];
};

// ---------------- camera ----------------
export type Cam = { pos: V3; look: V3; fov: number; roll: number };
type Shot = Partial<Cam> & { pos: V3; look: V3 };
type Key = { f: number; dur?: number; cut?: boolean; s: (f: number) => Shot };

const mix = (a: Cam, b: Cam, k: number): Cam => ({
  pos: a.pos.map((v, i) => v + (b.pos[i] - v) * k) as V3,
  look: a.look.map((v, i) => v + (b.look[i] - v) * k) as V3,
  fov: a.fov + (b.fov - a.fov) * k,
  roll: a.roll + (b.roll - a.roll) * k,
});
const full = (c: Shot): Cam => ({ fov: 40, roll: 0, ...c });
const run = (keys: Key[], f: number): Cam => {
  let cur = full(keys[0].s(f));
  for (let i = 1; i < keys.length; i++) {
    const k = keys[i];
    if (f < k.f) break;
    cur = k.cut
      ? full(k.s(f))
      : mix(cur, full(k.s(f)), glide((f - k.f) / (k.dur ?? 24)));
  }
  return cur;
};

const push = (f: number, f0: number, rate = 0.0022) => Math.max(0, f - f0) * rate;
const pushToward = (pos: V3, look: V3, k: number): { pos: V3; look: V3 } => ({
  pos: [
    pos[0] + (look[0] - pos[0]) * k,
    pos[1] + (look[1] - pos[1]) * k,
    pos[2] + (look[2] - pos[2]) * k,
  ],
  look,
});

// Impact kicks (7-frame alternating flip-shake)
const KICKS: [number, number][] = [
  [650, 0.14],   // Slap sticker on ID
  [1185, 0.12],  // Autopilot switch
  [1485, 0.25],  // Caught in France!
  [2130, 0.16],  // Hollywood flash
];

export const camAt = (id: number, f: number): Cam => {
  const ox = SHOTS[id - 1].ox;
  let c: Cam;

  switch (id) {
    case 1: // Hook: airport runway + jetliner + Frank with FREE ticket
      c = run([
        { f: 0, s: (ff) => ({ ...pushToward([ox - 4.2, 2.2, 11.5], [ox, 1.5, 0], push(ff, 0, 0.0028)), fov: 42, roll: -0.04 }) },
        { f: 75, dur: 32, s: (ff) => ({ ...pushToward([ox + 1.8, 1.8, 7.2], [ox, 1.45, 0], push(ff, 75, 0.0025)), fov: 36, roll: 0.03 }) },
      ], f);
      break;
    case 2: // 1960s bank street: empty bank account
      c = run([
        { f: 180, s: (ff) => ({ ...pushToward([ox + 0.5, 2.0, 9.5], [ox, 1.4, 0], push(ff, 180, 0.0022)), fov: 40 }) },
        { f: 280, dur: 26, s: (ff) => ({ ...pushToward([ox - 2.2, 1.65, 5.4], [ox, 1.5, 0], push(ff, 280, 0.003)), fov: 34, roll: -0.05 }) },
      ], f);
      break;
    case 3: // Pan Am uniform shop: phone call -> strut out in uniform
      c = run([
        { f: 370, s: (ff) => ({ ...pushToward([ox - 3.5, 1.9, 8.2], [ox - 1.5, 1.4, 0], push(ff, 370, 0.002)), fov: 38 }) },
        { f: 475, dur: 28, s: (ff) => ({ ...pushToward([ox + 2.2, 1.65, 6.2], [ox + 1.2, 1.45, 0], push(ff, 475, 0.0028)), fov: 35, roll: 0.05 }) },
      ], f);
      break;
    case 4: // Workbench: toy plane -> sticker -> fake ID
      c = run([
        { f: 578, s: (ff) => ({ ...pushToward([ox - 1.4, 2.1, 4.8], [ox, 1.35, 0], push(ff, 578, 0.003)), fov: 32, roll: 0.04 }) },
      ], f);
      break;
    case 5: // Boarding gate: real pilots flashing badges
      c = run([
        { f: 748, s: (ff) => ({ ...pushToward([ox + 6.5, 2.1, 9.0], [ox + 4.0, 1.5, 4.0], push(ff, 748, 0.0022)), fov: 40 }) },
      ], f);
      break;
    case 6: // Past security: Frank flashes toy sticker
      c = run([
        { f: 906, s: (ff) => ({ ...pushToward([ox - 4.0, 1.75, 7.8], [ox - 2.5, 1.45, 3.0], push(ff, 906, 0.0028)), fov: 36, roll: -0.04 }) },
      ], f);
      break;
    case 7: // Cockpit golden hour: captain offers yoke -> Frank flips autopilot
      c = run([
        { f: 1046, s: (ff) => ({ ...pushToward([ox - 2.2, 22.0, 6.5], [ox, 21.3, 0], push(ff, 1046, 0.002)), fov: 40, roll: 0.05 }) },
        { f: 1155, dur: 26, s: (ff) => ({ ...pushToward([ox + 1.4, 21.7, 4.4], [ox + 0.3, 21.4, 0], push(ff, 1155, 0.0032)), fov: 32, roll: -0.06 }) },
      ], f);
      break;
    case 8: // Luxury hotel balcony: 1,000,000 miles
      c = run([
        { f: 1262, s: (ff) => ({ ...pushToward([ox - 3.0, 2.3, 8.8], [ox, 1.5, 0], push(ff, 1262, 0.0025)), fov: 40, roll: 0.04 }) },
      ], f);
      break;
    case 9: // Paris street: police catch him in France
      c = run([
        { f: 1420, s: (ff) => ({ ...pushToward([ox + 3.2, 2.0, 9.2], [ox, 1.5, 0], push(ff, 1420, 0.0025)), fov: 42 }) },
        { f: 1485, dur: 18, s: (ff) => ({ ...pushToward([ox - 0.6, 1.65, 5.2], [ox, 1.45, 0], push(ff, 1485, 0.003)), fov: 34, roll: 0.07 }) },
      ], f);
      break;
    case 10: // Psychology town square
      c = run([
        { f: 1570, s: (ff) => ({ ...pushToward([ox - 2.5, 2.1, 8.0], [ox, 1.55, 0], push(ff, 1570, 0.0025)), fov: 38, roll: -0.03 }) },
      ], f);
      break;
    case 11: // High-vis vest + clipboard analogy
      c = run([
        { f: 1710, s: (ff) => ({ ...pushToward([ox - 3.6, 1.9, 8.5], [ox, 1.45, 0], push(ff, 1710, 0.0022)), fov: 40 }) },
        { f: 1815, dur: 26, s: (ff) => ({ ...pushToward([ox + 2.4, 1.75, 5.8], [ox + 0.8, 1.5, 0], push(ff, 1815, 0.0028)), fov: 34, roll: 0.05 }) },
      ], f);
      break;
    case 12: // Investigator archive desk: exaggerated flights
      c = run([
        { f: 1940, s: (ff) => ({ ...pushToward([ox + 1.8, 2.2, 6.2], [ox, 1.35, 0], push(ff, 1940, 0.0028)), fov: 35, roll: -0.04 }) },
      ], f);
      break;
    default: // 13: Hollywood red carpet twist
      c = run([
        { f: 2110, s: (ff) => ({ ...pushToward([ox - 3.2, 2.0, 8.8], [ox, 1.55, 0], push(ff, 2110, 0.0026)), fov: 40, roll: 0.04 }) },
        { f: 2210, dur: 24, s: (ff) => ({ ...pushToward([ox + 0.8, 1.7, 5.2], [ox, 1.5, 0], push(ff, 2210, 0.0032)), fov: 33, roll: -0.04 }) },
      ], f);
      break;
  }

  for (const [kf, amp] of KICKS) {
    const dt = f - kf;
    if (dt >= 0 && dt < 7) {
      const s = (dt % 2 === 0 ? 1 : -1) * amp * (1 - dt / 7);
      c = { ...c, pos: [c.pos[0] + s, c.pos[1] + s * 0.6, c.pos[2]], roll: c.roll + s * 0.15 };
    }
  }
  return c;
};

export const dofAt = (f: number): { cInf: number; focus?: (f: number) => V3 } => {
  const s = shotAt(f);
  if (s.id === 1 && f >= 75) return { cInf: 13 };
  if (s.id === 4) return { cInf: 14 }; // close-up toy plane & badge
  if (s.id === 7 && f >= 1155) return { cInf: 12 }; // autopilot close-up
  if (s.id === 9 && f >= 1485) return { cInf: 11 }; // caught close-up
  if (s.id === 12) return { cInf: 12 }; // archive desk close-up
  if (s.id === 13 && f >= 2210) return { cInf: 10 }; // Hollywood close-up
  return { cInf: 6 };
};
