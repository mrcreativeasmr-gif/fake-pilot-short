import React from "react";
import { AbsoluteFill, useCurrentFrame, useVideoConfig } from "remotion";
import words from "./words.json";

type WordItem = { w: string; s: number; e: number };

const HIGHLIGHT = new Set([
  "250", "free", "free!", "empty.", "co-pilot.", "toy", "fake", "id.",
  "sticker,", "autopilot.", "million", "luxury", "checks,", "france.",
  "psychology.", "vest", "clipboard?", "exaggerated", "hollywood", "movie"
]);

export const Captions: React.FC = () => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = f / fps;

  const list = words as WordItem[];
  const idx = list.findIndex((x) => t >= x.s && t <= x.e + 0.08);
  if (idx < 0) return null;

  // Group into 1-2 word chunks
  const chunkIdx = Math.floor(idx / 2) * 2;
  const pair = list.slice(chunkIdx, chunkIdx + 2);

  return (
    <AbsoluteFill
      style={{
        justifyContent: "flex-end",
        alignItems: "center",
        paddingBottom: 260,
        pointerEvents: "none",
      }}
    >
      <div
        style={{
          display: "flex",
          gap: 16,
          fontFamily: "Impact, 'Arial Black', sans-serif",
          fontWeight: 900,
          fontSize: 78,
          letterSpacing: 1.5,
          textTransform: "uppercase",
          textAlign: "center",
          WebkitTextStroke: "5px #0b0a0c",
          paintOrder: "stroke fill",
          textShadow: "0 6px 14px rgba(0,0,0,0.45)",
        }}
      >
        {pair.map((item, i) => {
          const active = chunkIdx + i === idx;
          const clean = item.w.toLowerCase();
          const color = HIGHLIGHT.has(clean)
            ? "#ffd43b"
            : active
            ? "#ffffff"
            : "#e4e8ee";
          return (
            <span
              key={i}
              style={{
                color,
                transform: active ? "scale(1.08)" : "scale(1.0)",
                display: "inline-block",
              }}
            >
              {item.w}
            </span>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};
