// Flat 2D bean-head cartoon cast for "The Fake Pilot Who Flew 250 Flights for Free"
// Design space: 600 x 1000 (soles at y = 975), plum ink #241726, stick limbs, deadpan lidded eyes.
export const INK = "#241726";
export const SKIN = "#ffe2c2";
const WHITE = "#ffffff";
const MOUTH = "#5a1e28";

type P2 = [number, number];
export type Expr = "calm" | "smug" | "shock" | "sad" | "wink" | "sweat" | "bored" | "proud";
export type Outfit = {
  jacket: string;
  pants: string;
  boots: string;
  tie?: string;
  hat?: "none" | "pilot" | "kepi" | "hardhat" | "hair";
  hatColor?: string;
  hair?: string;
  vest?: string;
  stripes?: boolean;
  moustache?: string;
  skin?: string;
  prop?: "none" | "ticket" | "badge" | "plane" | "clipboard" | "check" | "trophy";
};

export const FRANK_TEEN: Outfit = {
  jacket: "#c95b3c",
  pants: "#37465b",
  boots: "#3c281e",
  hat: "hair",
  hair: "#4f3222",
  skin: SKIN,
};

export const FRANK_PILOT: Outfit = {
  jacket: "#1d3557",
  pants: "#1d3557",
  boots: INK,
  tie: "#111b2b",
  hat: "pilot",
  hatColor: "#f4f6f9",
  stripes: true,
  skin: SKIN,
};

export const CAPTAIN: Outfit = {
  jacket: "#182b47",
  pants: "#182b47",
  boots: INK,
  tie: "#111b2b",
  hat: "pilot",
  hatColor: "#f4f6f9",
  stripes: true,
  moustache: "#5c4b3f",
  skin: "#f5c9a0",
};

export const AGENT: Outfit = {
  jacket: "#3b6e8c",
  pants: "#2b3745",
  boots: INK,
  tie: "#d64545",
  hat: "hair",
  hair: "#2f2420",
  skin: "#ecd0b6",
};

export const GENDARME: Outfit = {
  jacket: "#253e73",
  pants: "#253e73",
  boots: INK,
  hat: "kepi",
  hatColor: "#253e73",
  moustache: "#2c221e",
  skin: "#f5c9a0",
};

export const VEST_GUY: Outfit = {
  jacket: "#4b5b6b",
  pants: "#3a4552",
  boots: "#4a3426",
  vest: "#d9ff1c",
  hat: "hardhat",
  hatColor: "#f5c527",
  prop: "clipboard",
  skin: "#ecd0b6",
};

export const HOLLYWOOD: Outfit = {
  jacket: "#1a1a22",
  pants: "#1a1a22",
  boots: INK,
  tie: "#d93838",
  hat: "hair",
  hair: "#4f3222",
  skin: SKIN,
};

export class Pen {
  g: CanvasRenderingContext2D;
  ol = 12;
  constructor(g: CanvasRenderingContext2D) {
    this.g = g;
  }
  poly(pts: P2[], fill: string | null, ol?: number) {
    const g = this.g;
    const w = ol ?? this.ol;
    g.beginPath();
    pts.forEach(([x, y], i) => (i ? g.lineTo(x, y) : g.moveTo(x, y)));
    g.closePath();
    if (fill) {
      g.fillStyle = fill;
      g.fill();
    }
    if (w) {
      g.lineWidth = w;
      g.strokeStyle = INK;
      g.lineJoin = "round";
      g.stroke();
    }
  }
  ell(cx: number, cy: number, rx: number, ry: number, fill: string | null, ol?: number) {
    const g = this.g;
    const w = ol ?? this.ol;
    g.beginPath();
    g.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
    if (fill) {
      g.fillStyle = fill;
      g.fill();
    }
    if (w) {
      g.lineWidth = w;
      g.strokeStyle = INK;
      g.stroke();
    }
  }
  limb(pts: P2[], w = 22) {
    const g = this.g;
    g.beginPath();
    pts.forEach(([x, y], i) => (i ? g.lineTo(x, y) : g.moveTo(x, y)));
    g.lineWidth = w;
    g.lineCap = "round";
    g.lineJoin = "round";
    g.strokeStyle = INK;
    g.stroke();
  }
  roundRect(x: number, y: number, w: number, h: number, r: number, fill: string | null, ol?: number) {
    const g = this.g;
    const lw = ol ?? this.ol;
    g.beginPath();
    g.roundRect(x, y, w, h, r);
    if (fill) {
      g.fillStyle = fill;
      g.fill();
    }
    if (lw) {
      g.lineWidth = lw;
      g.strokeStyle = INK;
      g.stroke();
    }
  }
}

export type PoseOpts = {
  expr?: Expr;
  blink?: boolean;
  walk?: number; // 0..1 cycle
  wave?: number; // -1..1 arm raise
  holdProp?: Outfit["prop"];
  lean?: number; // radians
};

export function drawCharacter(p: Pen, o: Outfit, opts: PoseOpts = {}) {
  const g = p.g;
  const expr = opts.expr ?? "calm";
  const walk = opts.walk ?? 0;
  const wave = opts.wave ?? 0;
  const prop = opts.holdProp ?? o.prop ?? "none";
  const bob = Math.abs(Math.sin(walk * Math.PI * 2)) * 18;
  const stride = Math.sin(walk * Math.PI * 2) * 58;
  const skin = o.skin ?? SKIN;

  g.save();
  if (opts.lean) {
    g.translate(300, 975);
    g.rotate(opts.lean);
    g.translate(-300, -975);
  }

  // Legs (stick limbs + boots, soles at y = 975)
  const hipY = 760 - bob;
  const footL: P2 = [258 - stride, 962 - Math.max(0, -stride) * 0.25];
  const footR: P2 = [342 + stride, 962 - Math.max(0, stride) * 0.25];
  p.limb([[265, hipY], [260 - stride * 0.4, 865], footL], 22);
  p.limb([[335, hipY], [340 + stride * 0.4, 865], footR], 22);
  p.ell(footL[0] + 12, footL[1], 28, 15, o.boots, 10);
  p.ell(footR[0] + 12, footR[1], 28, 15, o.boots, 10);

  // Back arm
  const shY = 530 - bob;
  p.limb([[225, shY], [185, shY + 95], [195 + stride * 0.35, shY + 185]], 20);
  p.ell(195 + stride * 0.35, shY + 185, 16, 16, skin, 8);

  // Bean torso
  const torsoTop = 495 - bob;
  p.roundRect(212, torsoTop, 176, 275, 72, o.jacket, 13);

  // Shirt & tie
  if (o.tie) {
    p.poly([[272, torsoTop + 6], [328, torsoTop + 6], [300, torsoTop + 72]], WHITE, 7);
    p.poly([[292, torsoTop + 26], [308, torsoTop + 26], [312, torsoTop + 120], [300, torsoTop + 138], [288, torsoTop + 120]], o.tie, 6);
  }

  // Gold pilot stripes
  if (o.stripes) {
    g.fillStyle = "#f2c94c";
    g.fillRect(232, torsoTop + 170, 52, 12);
    g.fillRect(232, torsoTop + 190, 52, 12);
    // Pilot wings badge on chest
    p.roundRect(318, torsoTop + 62, 42, 18, 6, "#f2c94c", 5);
  }

  // High-vis vest
  if (o.vest) {
    p.roundRect(216, torsoTop + 18, 168, 225, 48, o.vest, 11);
    g.fillStyle = "#e8f2f5";
    g.fillRect(222, torsoTop + 145, 156, 24);
  }

  // Bean head (h/w ~ 0.94, centered at x=300, y=340 - bob)
  const hy = 342 - bob;
  p.ell(300, hy, 128, 120, skin, 13);

  // Subtle shadow crescent on left cheek
  g.save();
  g.beginPath();
  g.ellipse(300, hy, 122, 114, 0, 0, Math.PI * 2);
  g.clip();
  g.fillStyle = "rgba(180, 120, 110, 0.14)";
  g.beginPath();
  g.ellipse(240, hy + 10, 85, 115, 0, 0, Math.PI * 2);
  g.fill();
  g.restore();

  // Eyes (deadpan lidded, 0.26W apart -> x=265 and x=345)
  const ey = hy - 8;
  for (const [idx, ex] of [268, 342].entries()) {
    if (opts.blink || (expr === "wink" && idx === 1)) {
      p.limb([[ex - 16, ey], [ex + 16, ey]], 9);
    } else {
      p.ell(ex, ey, 16, 19, WHITE, 8);
      p.ell(ex + 3, ey + 1, 7, 9, INK, 0);
      // Heavy deadpan eyelid for calm/smug/bored
      if (expr === "calm" || expr === "smug" || expr === "bored") {
        g.fillStyle = skin;
        g.fillRect(ex - 20, ey - 22, 40, 15);
        p.limb([[ex - 18, ey - 7], [ex + 18, ey - 7]], 8);
      }
    }
  }

  // Brows
  if (expr === "shock" || expr === "sweat") {
    p.limb([[250, ey - 36], [284, ey - 44]], 8);
    p.limb([[326, ey - 44], [360, ey - 36]], 8);
  } else if (expr === "smug" || expr === "proud") {
    p.limb([[250, ey - 28], [284, ey - 34]], 8);
    p.limb([[324, ey - 34], [358, ey - 24]], 8);
  } else if (expr === "sad") {
    p.limb([[250, ey - 22], [284, ey - 34]], 8);
    p.limb([[324, ey - 34], [358, ey - 22]], 8);
  }

  // Moustache
  if (o.moustache) {
    p.ell(304, hy + 30, 38, 12, o.moustache, 7);
  }

  // Mouth
  const my = hy + 46;
  if (expr === "smug" || expr === "proud" || expr === "wink") {
    p.limb([[276, my], [306, my + 8], [336, my - 10]], 9);
  } else if (expr === "shock") {
    p.ell(305, my + 6, 20, 26, MOUTH, 8);
  } else if (expr === "sad") {
    p.limb([[276, my + 10], [304, my - 4], [332, my + 10]], 9);
  } else {
    p.limb([[280, my], [326, my]], 9);
  }

  // Sweat drop
  if (expr === "sweat") {
    p.poly([[398, hy - 35], [412, hy - 5], [398, hy + 10], [384, hy - 5]], "#7cd4ff", 6);
  }

  // Hats & Hair
  if (o.hat === "pilot") {
    p.poly([[185, hy - 70], [415, hy - 70], [438, hy - 122], [162, hy - 122]], o.hatColor ?? WHITE, 11);
    p.roundRect(178, hy - 75, 244, 28, 8, "#142238", 9);
    p.ell(300, hy - 44, 118, 16, INK, 6); // visor
    p.ell(300, hy - 96, 20, 14, "#f2c94c", 5); // gold emblem
  } else if (o.hat === "kepi") {
    p.roundRect(212, hy - 122, 176, 62, 14, o.hatColor ?? "#253e73", 10);
    p.roundRect(210, hy - 68, 180, 16, 4, "#f2c94c", 6);
    p.ell(300, hy - 48, 110, 14, INK, 6);
  } else if (o.hat === "hardhat") {
    p.ell(300, hy - 75, 134, 62, o.hatColor ?? "#f5c527", 11);
    p.roundRect(160, hy - 68, 280, 22, 10, o.hatColor ?? "#f5c527", 9);
  } else if (o.hat === "hair") {
    p.poly(
      [[175, hy - 45], [190, hy - 115], [250, hy - 138], [335, hy - 136], [410, hy - 102], [422, hy - 45], [350, hy - 80], [240, hy - 78]],
      o.hair ?? "#4f3222",
      11
    );
  }

  // Front arm + props
  const handX = 395 + wave * 42;
  const handY = shY + 165 - wave * 135;
  p.limb([[372, shY], [385 + wave * 18, shY + 85], [handX, handY]], 20);
  p.ell(handX, handY, 16, 16, skin, 8);

  if (prop === "ticket") {
    p.roundRect(handX - 18, handY - 62, 95, 56, 8, "#f5f0dc", 8);
    g.fillStyle = "#e03e3e";
    g.font = "900 22px sans-serif";
    g.fillText("FREE", handX - 4, handY - 26);
  } else if (prop === "badge") {
    p.roundRect(handX - 10, handY - 58, 72, 52, 8, "#ffffff", 8);
    p.ell(handX + 26, handY - 32, 14, 14, "#2d8cff", 5);
  } else if (prop === "clipboard") {
    p.roundRect(handX - 14, handY - 72, 74, 92, 8, "#b87a4b", 8);
    p.roundRect(handX - 4, handY - 58, 54, 68, 4, WHITE, 5);
  } else if (prop === "check") {
    p.roundRect(handX - 12, handY - 48, 86, 44, 6, "#d9f2d9", 7);
    g.fillStyle = "#1d7a36";
    g.font = "bold 20px sans-serif";
    g.fillText("$$$", handX + 10, handY - 19);
  } else if (prop === "plane") {
    p.poly([[handX - 10, handY - 22], [handX + 85, handY - 42], [handX + 45, handY - 12]], "#e8eef5", 7);
  } else if (prop === "trophy") {
    p.roundRect(handX - 14, handY - 72, 46, 46, 10, "#f2c94c", 8);
  }

  g.restore();
}

// 2D effect cards
export function fxStars(p: Pen) {
  const pts: P2[] = [];
  for (let i = 0; i < 10; i++) {
    const a = (i * Math.PI) / 5 - Math.PI / 2;
    const r = i % 2 === 0 ? 110 : 48;
    pts.push([300 + Math.cos(a) * r, 300 + Math.sin(a) * r]);
  }
  p.poly(pts, "#ffe047", 10);
}

export function fxRing(p: Pen) {
  p.ell(300, 300, 140, 140, null, 18);
  p.ell(300, 300, 95, 95, null, 10);
}

export function fxBanner(p: Pen, text: string, bg: string, fg: string) {
  const g = p.g;
  p.roundRect(30, 110, 540, 160, 26, bg, 14);
  g.fillStyle = fg;
  g.font = "900 72px sans-serif";
  g.textAlign = "center";
  g.textBaseline = "middle";
  g.fillText(text, 300, 192);
}
