// Cast & 2D effect cards on NOINK layer with cardShade() scene lighting
import * as THREE from "three";
import {
  Pen, drawCharacter, fxStars, fxRing, fxBanner,
  FRANK_TEEN, FRANK_PILOT, CAPTAIN, AGENT, GENDARME, VEST_GUY, HOLLYWOOD,
  Outfit, PoseOpts,
} from "./toon";
import { SHOTS, V3 } from "./story";
import { NOINK } from "./ink";
import { cardShade, blobMaterial } from "./cardshade";

type Entry = { cv: HTMLCanvasElement; tex: THREE.CanvasTexture; w: number; h: number };
export type Req = { key: string; w: number; h: number; draw: (p: Pen) => void; tex?: THREE.CanvasTexture };

const makeEntry = (w: number, h: number): Entry => {
  const cv = document.createElement("canvas");
  cv.width = w;
  cv.height = h;
  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return { cv, tex, w, h };
};

export class Pool {
  private live = new Map<string, Entry>();
  private reqs: Req[] = [];
  req(key: string, w: number, h: number, draw: (p: Pen) => void): Req {
    const r: Req = { key: `${w}x${h}|${key}`, w, h, draw };
    this.reqs.push(r);
    return r;
  }
  flush() {
    for (const r of this.reqs) {
      let e = this.live.get(r.key);
      if (!e) {
        e = makeEntry(r.w, r.h);
        const g = e.cv.getContext("2d")!;
        g.clearRect(0, 0, e.w, e.h);
        r.draw(new Pen(g));
        e.tex.needsUpdate = true;
        this.live.set(r.key, e);
      }
      r.tex = e.tex;
    }
    this.reqs = [];
  }
}

const blank = (() => {
  const c = document.createElement("canvas");
  c.width = c.height = 2;
  return new THREE.CanvasTexture(c);
})();
const SU = 0.00216;
const BODY = (() => {
  const g = new THREE.PlaneGeometry(600 * SU, 1000 * SU);
  g.translate(0, (975 - 500) * SU, 0);
  return g;
})();
const CARD = new THREE.PlaneGeometry(1.4, 0.9);
const BLOB = new THREE.PlaneGeometry(1.1, 1.1);

export class Actor {
  mesh: THREE.Mesh;
  mat: THREE.MeshLambertMaterial;
  blob: THREE.Mesh;
  r: Req | null = null;
  constructor(parent: THREE.Object3D) {
    this.mat = cardShade(new THREE.MeshLambertMaterial({ map: blank, alphaTest: 0.5, side: THREE.DoubleSide }));
    this.mesh = new THREE.Mesh(BODY, this.mat);
    this.mesh.receiveShadow = true;
    this.mesh.visible = false;
    this.mesh.layers.set(NOINK);
    this.mesh.renderOrder = 1;
    parent.add(this.mesh);

    this.blob = new THREE.Mesh(BLOB, blobMaterial(blank));
    this.blob.rotation.x = -Math.PI / 2;
    this.blob.visible = false;
    this.blob.layers.set(NOINK);
    parent.add(this.blob);
  }
  show(pos: V3, camPos: V3, flip = false) {
    this.mesh.visible = true;
    this.mesh.position.set(pos[0], pos[1], pos[2]);
    this.mesh.rotation.y = Math.atan2(camPos[0] - pos[0], camPos[2] - pos[2]);
    this.mesh.scale.x = flip ? -1 : 1;
    this.blob.visible = true;
    this.blob.position.set(pos[0], pos[1] + 0.03, pos[2]);
    if (this.r?.tex) this.mat.map = this.r.tex;
  }
  hide() {
    this.mesh.visible = false;
    this.blob.visible = false;
  }
}

export class FxCard {
  mesh: THREE.Mesh;
  mat: THREE.MeshBasicMaterial;
  r: Req | null = null;
  constructor(parent: THREE.Object3D) {
    this.mat = new THREE.MeshBasicMaterial({ map: blank, alphaTest: 0.5, side: THREE.DoubleSide });
    this.mesh = new THREE.Mesh(CARD, this.mat);
    this.mesh.visible = false;
    this.mesh.layers.set(NOINK);
    parent.add(this.mesh);
  }
  show(pos: V3, camPos: V3, scale = 1.0) {
    this.mesh.visible = true;
    this.mesh.position.set(pos[0], pos[1], pos[2]);
    this.mesh.rotation.y = Math.atan2(camPos[0] - pos[0], camPos[2] - pos[2]);
    this.mesh.scale.setScalar(scale);
    if (this.r?.tex) this.mat.map = this.r.tex;
  }
  hide() {
    this.mesh.visible = false;
  }
}

export class Cast {
  pool = new Pool();
  actors: Actor[] = [];
  fxs: FxCard[] = [];
  constructor(parent: THREE.Object3D) {
    for (let i = 0; i < 6; i++) this.actors.push(new Actor(parent));
    for (let i = 0; i < 4; i++) this.fxs.push(new FxCard(parent));
  }
  private pose(idx: number, key: string, outfit: Outfit, opts: PoseOpts, pos: V3, camPos: V3, flip = false) {
    const a = this.actors[idx];
    a.r = this.pool.req(key, 600, 1000, (p) => drawCharacter(p, outfit, opts));
    a.show(pos, camPos, flip);
  }
  private fx(idx: number, key: string, draw: (p: Pen) => void, pos: V3, camPos: V3, scale = 1.0) {
    const c = this.fxs[idx];
    c.r = this.pool.req(key, 600, 400, draw);
    c.show(pos, camPos, scale);
  }

  update(id: number, f: number, camPos: V3) {
    for (const a of this.actors) a.hide();
    for (const c of this.fxs) c.hide();
    const ox = SHOTS[id - 1].ox;
    const blink = f % 68 >= 64;
    const walk = ((f % 24) / 24);

    switch (id) {
      case 1: // Hook: Frank in pilot uniform holding FREE ticket
        this.pose(0, `fp_hook_${blink}`, FRANK_PILOT, { expr: "smug", blink, wave: 0.7, holdProp: "ticket" }, [ox, 0.08, 0.5], camPos);
        this.fx(0, "b_250", (p) => fxBanner(p, "250 FLIGHTS", "#ffd43b", "#142238"), [ox + 0.2, 2.75, 0.4], camPos, 1.3);
        break;
      case 2: // 1960s bank: Frank teen sad with empty account
        this.pose(0, `ft_sad_${blink}`, FRANK_TEEN, { expr: "sad", blink, wave: 0.2 }, [ox, 0.08, 0.5], camPos);
        this.fx(0, "b_000", (p) => fxBanner(p, "$0.00", "#e85d5d", "#ffffff"), [ox + 0.1, 2.6, 0.3], camPos, 1.1);
        break;
      case 3: // Uniform shop: phone -> walks out as co-pilot
        if (f < 470) {
          this.pose(0, `ft_call_${blink}`, FRANK_TEEN, { expr: "wink", blink, wave: 0.85 }, [ox - 1.5, 0.08, -0.3], camPos);
        } else {
          const wx = ox - 0.5 + ((f - 470) / 108) * 2.4;
          this.pose(0, `fp_walk_${Math.floor(walk * 8)}`, FRANK_PILOT, { expr: "proud", walk, wave: 0.3 }, [wx, 0.08, 0.6], camPos);
        }
        break;
      case 4: // Workbench: toy plane + fake ID
        this.pose(0, `fp_id_${blink}`, FRANK_PILOT, { expr: "wink", blink, wave: 0.5, holdProp: "plane" }, [ox - 0.2, 0.08, 1.4], camPos);
        this.fx(0, "b_id", (p) => fxBanner(p, "FAKE ID", "#4ea8de", "#ffffff"), [ox + 0.8, 2.25, 0.3], camPos, 0.95);
        break;
      case 5: // Gate: real pilots flashing badges
        this.pose(0, `cap_gate_${Math.floor(walk * 6)}`, CAPTAIN, { expr: "calm", walk, wave: 0.8, holdProp: "badge" }, [ox + 3.4, 0.08, 3.8], camPos);
        this.pose(1, `ag_gate_${blink}`, AGENT, { expr: "proud", blink, wave: 0.6 }, [ox + 5.1, 0.08, 3.6], camPos, true);
        break;
      case 6: // Security: Frank flashes sticker badge past guard
        this.pose(0, `fp_sec_${Math.floor(walk * 6)}`, FRANK_PILOT, { expr: "smug", walk, wave: 0.85, holdProp: "badge" }, [ox - 3.0, 0.08, 3.2], camPos);
        this.pose(1, `ag_sec_${blink}`, AGENT, { expr: "calm", blink, wave: 0.9 }, [ox - 1.4, 0.08, 2.9], camPos, true);
        this.fx(0, "fx_ring", fxRing, [ox - 2.3, 2.3, 2.8], camPos, 1.1);
        break;
      case 7: // Cockpit golden hour: Captain + Frank flipping autopilot
        this.pose(0, `cap_cockpit_${blink}`, CAPTAIN, { expr: "calm", blink, wave: 0.7 }, [ox - 1.1, 20.2, 0.2], camPos);
        this.pose(1, `fp_cockpit_${f > 1155 ? "smug" : "sweat"}`, FRANK_PILOT, { expr: f > 1155 ? "smug" : "sweat", wave: f > 1155 ? 0.9 : 0.4 }, [ox + 0.9, 20.2, 0.2], camPos, true);
        this.fx(0, "b_auto", (p) => fxBanner(p, "AUTOPILOT", "#38d9a9", "#0c2b21"), [ox, 22.7, -0.5], camPos, 1.1);
        break;
      case 8: // Luxury hotel: 1,000,000 miles
        this.pose(0, `fp_hotel_${blink}`, FRANK_PILOT, { expr: "smug", blink, wave: 0.6, holdProp: "check" }, [ox, 0.12, 0.5], camPos);
        this.fx(0, "b_1m", (p) => fxBanner(p, "1,000,000 MI", "#ffd43b", "#142238"), [ox + 0.2, 2.8, 0.3], camPos, 1.25);
        break;
      case 9: // Paris: French police arrest Frank
        this.pose(0, `fp_arrest`, FRANK_PILOT, { expr: "shock", wave: 1.0, holdProp: "check" }, [ox, 0.08, 0.5], camPos);
        this.pose(1, `gen1_${blink}`, GENDARME, { expr: "calm", blink, wave: 0.7 }, [ox - 1.5, 0.08, 0.7], camPos);
        this.pose(2, `gen2_${blink}`, GENDARME, { expr: "calm", blink, wave: 0.7 }, [ox + 1.5, 0.08, 0.7], camPos, true);
        break;
      case 10: // Psychology square
        this.pose(0, `fp_psy_${blink}`, FRANK_PILOT, { expr: "wink", blink, wave: 0.5 }, [ox, 0.1, 0.5], camPos);
        this.fx(0, "fx_stars", fxStars, [ox, 2.7, 0.3], camPos, 1.15);
        break;
      case 11: // High-vis vest + clipboard analogy
        const vx = ox - 1.8 + ((f - 1710) / 230) * 3.2;
        this.pose(0, `vg_${Math.floor(walk * 8)}`, VEST_GUY, { expr: "smug", walk, wave: 0.35, holdProp: "clipboard" }, [vx, 0.08, 0.7], camPos);
        this.pose(1, `ag_vest_${blink}`, AGENT, { expr: "bored", blink, wave: 0.75 }, [ox + 1.8, 0.08, 0.4], camPos, true);
        break;
      case 12: // Archive desk: exaggerated
        this.pose(0, `ag_arch_${blink}`, AGENT, { expr: "shock", blink, wave: 0.4 }, [ox - 0.8, 0.08, 1.3], camPos);
        this.fx(0, "b_fake", (p) => fxBanner(p, "EXAGGERATED!", "#ff6b6b", "#ffffff"), [ox + 0.4, 2.45, 0.3], camPos, 1.2);
        break;
      default: // 13: Hollywood twist
        this.pose(0, `hw_${blink}`, HOLLYWOOD, { expr: "smug", blink, wave: 0.85, holdProp: "trophy" }, [ox, 0.08, 0.8], camPos);
        this.fx(0, "b_holly", (p) => fxBanner(p, "HOLLYWOOD", "#ffd43b", "#1a1a22"), [ox, 2.85, 0.3], camPos, 1.3);
        break;
    }

    this.pool.flush();
    for (const a of this.actors) if (a.mesh.visible && a.r?.tex) a.mat.map = a.r.tex;
    for (const c of this.fxs) if (c.mesh.visible && c.r?.tex) c.mat.map = c.r.tex;
  }
}
