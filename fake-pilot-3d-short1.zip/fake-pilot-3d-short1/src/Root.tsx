import React from "react";
import { Composition } from "remotion";
import { FakePilotShort, FAKE_PILOT_FRAMES } from "./videos/fakePilot/FakePilot";

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="FakePilotShort"
      component={FakePilotShort}
      durationInFrames={FAKE_PILOT_FRAMES}
      fps={30}
      width={1080}
      height={1920}
    />
  );
};
