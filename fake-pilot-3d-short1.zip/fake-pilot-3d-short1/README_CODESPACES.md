# Fake Pilot Who Flew 250 Flights for Free (3D Cartoon Short)

## GitHub Codespaces Render Guide
1. Open your GitHub repository in **GitHub Codespaces**.
2. Drag-and-drop `fake-pilot-3d-short.zip` into the Codespaces file explorer (upload directly into the workspace, not GitHub's web upload).
3. In the Codespaces terminal, run:
```bash
unzip fake-pilot-3d-short.zip -d fake-pilot-short
cd fake-pilot-short
bash render.sh
```
4. Once complete, right-click `out/final_fake_pilot.mp4` in the explorer and select **Download**.
