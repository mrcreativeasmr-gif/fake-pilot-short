#!/usr/bin/env bash
set -euo pipefail

mkdir -p out
echo "1/3 Installing dependencies..."
npm install --no-audit --no-fund

echo "2/3 Rendering 3D Remotion Short (1080x1920 -> 2K 1440x2560)..."
npx remotion render src/index.ts FakePilotShort out/video.mp4 \
  --codec h264 \
  --crf 16 \
  --scale 1.3333 \
  --gl=angle

echo "3/3 Muxing final video with synced mix.wav..."
ffmpeg -y -i out/video.mp4 -i public/mix.wav \
  -c:v copy -c:a aac -b:a 192k \
  -map 0:v:0 -map 1:a:0 \
  out/final_fake_pilot.mp4

echo "DONE! Final video ready at: out/final_fake_pilot.mp4"
