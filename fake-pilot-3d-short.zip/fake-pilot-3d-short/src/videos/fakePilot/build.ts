// Procedural 3D inked world for "The Fake Pilot Who Flew 250 Flights for Free"
// Uses two-tone shading (shade.ts) + muted architectural albedos + dark-ink silhouettes (ink.ts).
import * as THREE from "three";
import { tone, untone } from "./shade";

export type Kit = Record<string, never>;
export const loadKit = async (): Promise<Kit> => ({});

const mat = (color: number, roughness = 0.85) =>
  tone(new THREE.MeshStandardMaterial({ color, roughness, metalness: 0.05 }));

const box = (w: number, h: number, d: number, color: number, cast = true) => {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat(color));
  m.castShadow = cast;
  m.receiveShadow = true;
  return m;
};

const cyl = (rt: number, rb: number, h: number, seg: number, color: number, cast = true) => {
  const m = new THREE.Mesh(new THREE.CylinderGeometry(rt, rb, h, seg), mat(color));
  m.castShadow = cast;
  m.receiveShadow = true;
  return m;
};

function addHouse(root: THREE.Group, x: number, z: number, w: number, h: number, d: number, wall: number, roof: number) {
  const g = new THREE.Group();
  g.position.set(x, 0, z);
  const body = box(w, h, d, wall);
  body.position.y = h / 2;
  g.add(body);
  // Plinth
  const plinth = box(w + 0.25, 0.7, d + 0.25, 0x7b756d);
  plinth.position.y = 0.35;
  g.add(plinth);
  // Cornice / Roof
  const cap = box(w + 0.35, 0.45, d + 0.35, roof);
  cap.position.y = h + 0.22;
  g.add(cap);
  // Windows
  const winMat = mat(0x4f759b, 0.3);
  for (let wy = 2.2; wy < h - 1.0; wy += 2.4) {
    for (let wx = -w * 0.28; wx <= w * 0.29; wx += w * 0.56) {
      const win = new THREE.Mesh(new THREE.BoxGeometry(1.1, 1.3, 0.15), winMat);
      win.position.set(wx, wy, d / 2 + 0.05);
      g.add(win);
    }
  }
  root.add(g);
}

function addTree(root: THREE.Group, x: number, z: number, scale = 1) {
  const g = new THREE.Group();
  g.position.set(x, 0, z);
  g.scale.setScalar(scale);
  const trunk = cyl(0.18, 0.28, 2.2, 7, 0x6b4c35);
  trunk.position.y = 1.1;
  g.add(trunk);
  const crown1 = new THREE.Mesh(new THREE.IcosahedronGeometry(1.4, 1), mat(0x4b8f4c));
  crown1.position.y = 3.1;
  crown1.castShadow = true;
  g.add(crown1);
  const crown2 = new THREE.Mesh(new THREE.IcosahedronGeometry(1.0, 1), mat(0x5da356));
  crown2.position.set(0.6, 2.7, 0.3);
  g.add(crown2);
  root.add(g);
}

function addJetliner(root: THREE.Group, x: number, y: number, z: number) {
  const g = new THREE.Group();
  g.position.set(x, y, z);
  // Fuselage
  const fuse = cyl(1.25, 1.25, 16, 14, 0xf2f4f7);
  fuse.rotation.z = Math.PI / 2;
  fuse.position.y = 2.4;
  g.add(fuse);
  // Blue Pan Am cheatline stripe
  const stripe = cyl(1.27, 1.27, 15.2, 14, 0x246eb9, false);
  stripe.rotation.z = Math.PI / 2;
  stripe.position.y = 2.4;
  stripe.scale.set(1, 0.22, 1);
  g.add(stripe);
  // Nose cone
  const nose = new THREE.Mesh(new THREE.SphereGeometry(1.25, 12, 10), mat(0xf2f4f7));
  nose.scale.set(1.6, 1, 1);
  nose.position.set(-8.0, 2.4, 0);
  g.add(nose);
  // Cockpit windshield
  const glass = box(1.0, 0.5, 1.4, 0x1c2c40, false);
  glass.position.set(-7.6, 2.95, 0);
  g.add(glass);
  // Wings
  const wing = box(3.4, 0.22, 15.0, 0xd8dfe6);
  wing.position.set(-0.5, 2.0, 0);
  g.add(wing);
  // Tail fin
  const tail = box(2.4, 3.6, 0.24, 0x246eb9);
  tail.position.set(6.8, 4.4, 0);
  g.add(tail);
  // Landing gear
  for (const gx of [-5.5, 0.5]) {
    const leg = cyl(0.12, 0.12, 1.3, 6, 0x333840);
    leg.position.set(gx, 0.7, 0);
    g.add(leg);
  }
  root.add(g);
}

export function buildWorld(root: THREE.Group) {
  // Continuous ground plane across all sets (X: -60..680)
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(900, 260), mat(0x7fa36a, 0.95));
  ground.rotation.x = -Math.PI / 2;
  ground.position.set(300, 0, 0);
  ground.receiveShadow = true;
  root.add(ground);

  // ---------------- 1. AIRPORT (ox = 0) ----------------
  const runway = box(44, 0.08, 18, 0x4b515c, false);
  runway.position.set(0, 0.04, 0);
  root.add(runway);
  for (let dx = -18; dx <= 18; dx += 4) {
    const dash = box(2.0, 0.09, 0.4, 0xf2eee4, false);
    dash.position.set(dx, 0.05, 0);
    root.add(dash);
  }
  addJetliner(root, 3.5, 0, -5.8);
  addHouse(root, -11, -12, 12, 7.5, 8, 0xd8cfc2, 0x3b6e8c);
  // Security arch at x = -2.5, z = 3.0
  const archL = box(0.35, 2.8, 0.6, 0x7b8899);
  archL.position.set(-3.4, 1.4, 3.0);
  const archR = box(0.35, 2.8, 0.6, 0x7b8899);
  archR.position.set(-1.6, 1.4, 3.0);
  const archT = box(2.2, 0.35, 0.6, 0x4c5868);
  archT.position.set(-2.5, 2.8, 3.0);
  root.add(archL, archR, archT);

  // ---------------- 2. 1960s BANK STREET (ox = 60) ----------------
  const road2 = box(36, 0.08, 14, 0x555b66, false);
  road2.position.set(60, 0.04, 0);
  root.add(road2);
  addHouse(root, 60, -9, 11, 9.2, 7, 0xd6b88d, 0x6b4e3d);
  addHouse(root, 49, -10, 8, 7.6, 7, 0xb86f58, 0x4a3530);
  addHouse(root, 71, -10, 8, 8.0, 7, 0xc9bfa8, 0x455a64);
  addTree(root, 53, -4);
  addTree(root, 67, -4.5);

  // ---------------- 3. UNIFORM SHOP (ox = 120) ----------------
  const road3 = box(36, 0.08, 14, 0x5d626b, false);
  road3.position.set(120, 0.04, 0);
  root.add(road3);
  addHouse(root, 120, -8, 12, 8.2, 7, 0xe0d6c3, 0x246eb9);
  // Retro phone booth at x = 117.5, z = -1.5
  const booth = box(1.1, 2.5, 1.1, 0xc93b3b);
  booth.position.set(117.5, 1.25, -1.5);
  root.add(booth);
  addTree(root, 128, -4);

  // ---------------- 4. HOBBY WORKBENCH (ox = 180) ----------------
  const table = box(8, 1.1, 4.5, 0x8f5d38);
  table.position.set(180, 0.55, 0);
  root.add(table);
  // Tiny toy model plane on table
  const toy = box(0.9, 0.25, 0.9, 0x246eb9);
  toy.position.set(179.4, 1.25, 0.4);
  const idCard = box(1.1, 0.08, 0.7, 0xf7f7f5, false);
  idCard.position.set(180.6, 1.15, 0.3);
  root.add(toy, idCard);
  addHouse(root, 180, -10, 14, 8, 6, 0xd1c1a5, 0x5c4738);

  // ---------------- 7. COCKPIT & CLOUDS (ox = 240, y = 20) ----------------
  const deck = box(7.5, 0.4, 5.5, 0x2c3645);
  deck.position.set(240, 20.0, 0);
  const dash = box(5.2, 1.1, 1.2, 0x1e2530);
  dash.position.set(240, 20.75, -1.8);
  // Glowing Autopilot button (HDR emissive for Bloom!)
  const autoMat = untone(new THREE.MeshBasicMaterial({ color: new THREE.Color(0.3, 2.2, 0.7) }));
  const autoBtn = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.28, 0.25), autoMat);
  autoBtn.position.set(240, 21.1, -1.1);
  root.add(deck, dash, autoBtn);
  // Fluffy clouds around cockpit
  for (let i = 0; i < 8; i++) {
    const cl = new THREE.Mesh(new THREE.IcosahedronGeometry(2.2 + (i % 3), 1), mat(0xf5f8fc, 0.95));
    cl.position.set(232 + i * 2.5, 17.5 + (i % 2) * 1.5, -10 - (i % 3) * 4);
    cl.scale.set(1.8, 0.7, 1.2);
    root.add(cl);
  }

  // ---------------- 8. LUXURY HOTEL (ox = 300) ----------------
  const terrace = box(22, 0.12, 14, 0xe8dcc5, false);
  terrace.position.set(300, 0.06, 0);
  root.add(terrace);
  addHouse(root, 300, -10, 14, 10.5, 7, 0xf0e6d2, 0xc76b4a);
  addTree(root, 293, -3.5, 1.2);
  addTree(root, 307, -3.5, 1.2);

  // ---------------- 9. PARIS STREET & EIFFEL TOWER (ox = 360) ----------------
  const parisRoad = box(36, 0.08, 14, 0x5c626d, false);
  parisRoad.position.set(360, 0.04, 0);
  root.add(parisRoad);
  addHouse(root, 352, -10, 8, 8.8, 7, 0xd9cfc1, 0x4c5868);
  addHouse(root, 368, -10, 8, 8.8, 7, 0xd1c5b4, 0x4c5868);
  // Stylized Eiffel Tower in background (z = -24)
  const eiffelBase = new THREE.Mesh(new THREE.ConeGeometry(4.2, 18, 4), mat(0x524c48));
  eiffelBase.rotation.y = Math.PI / 4;
  eiffelBase.position.set(360, 9.0, -24);
  root.add(eiffelBase);

  // ---------------- 10. PSYCHOLOGY SQUARE (ox = 420) ----------------
  const plaza = box(24, 0.1, 16, 0xc9c2b2, false);
  plaza.position.set(420, 0.05, 0);
  root.add(plaza);
  addHouse(root, 420, -11, 14, 8.5, 6, 0xc7956d, 0x495a66);

  // ---------------- 11. CONSTRUCTION GATE / HIGH-VIS VEST (ox = 480) ----------------
  const gateRoad = box(32, 0.08, 14, 0x5c6066, false);
  gateRoad.position.set(480, 0.04, 0);
  root.add(gateRoad);
  const boothG = box(2.4, 2.8, 2.4, 0xd8d0c0);
  boothG.position.set(482.5, 1.4, -2.5);
  const barrier = box(5.5, 0.2, 0.2, 0xe8483c);
  barrier.position.set(479, 1.2, 0.5);
  barrier.rotation.z = 0.35; // raised gate!
  root.add(boothG, barrier);
  addHouse(root, 480, -11, 14, 9.0, 6, 0x9aa3ad, 0x3b4552);

  // ---------------- 12. ARCHIVE DESK (ox = 540) ----------------
  const floor12 = box(20, 0.1, 14, 0x856649, false);
  floor12.position.set(540, 0.05, 0);
  const desk12 = box(5.5, 1.1, 2.5, 0x5c3e28);
  desk12.position.set(540, 0.55, 0);
  const stack = box(0.9, 0.8, 0.9, 0xf2eee4);
  stack.position.set(538.8, 1.5, 0.2);
  root.add(floor12, desk12, stack);

  // ---------------- 13. HOLLYWOOD RED CARPET (ox = 600) ----------------
  const carpet = box(5.0, 0.08, 16, 0xb82525, false);
  carpet.position.set(600, 0.05, 0);
  root.add(carpet);
  addHouse(root, 600, -10, 15, 9.5, 7, 0x2b2938, 0xd9a441);
  // HDR Emissive Marquee Bulbs for Bloom!
  const bulbMat = untone(new THREE.MeshBasicMaterial({ color: new THREE.Color(2.4, 1.9, 0.7) }));
  for (let bx = -5; bx <= 5; bx += 2) {
    const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.26, 8, 8), bulbMat);
    bulb.position.set(600 + bx, 7.6, -6.3);
    root.add(bulb);
  }
}
