// 3D World controller: sky shader, fog, sun lighting, and per-frame cast/camera updates
import * as THREE from "three";
import { buildWorld, Kit } from "./build";
import { Cast } from "./cast";
import { camAt, SHOTS } from "./story";
import { LIGHTS, LOOK, sunDir } from "./lights";
import { setShade } from "./shade";
import { setCardSun } from "./cardshade";

export class World {
  root = new THREE.Group();
  sun = new THREE.DirectionalLight(0xffffff, 1.5);
  amb = new THREE.AmbientLight(0xffffff, 0.5);
  skyMat: THREE.ShaderMaterial;
  cast: Cast;

  constructor(_kit: Kit) {
    buildWorld(this.root);
    this.cast = new Cast(this.root);

    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(1024, 1024);
    this.sun.shadow.camera.near = 1;
    this.sun.shadow.camera.far = 80;
    this.sun.shadow.camera.left = -22;
    this.sun.shadow.camera.right = 22;
    this.sun.shadow.camera.top = 22;
    this.sun.shadow.camera.bottom = -22;
    this.root.add(this.sun, this.sun.target, this.amb);

    this.skyMat = new THREE.ShaderMaterial({
      side: THREE.BackSide,
      depthWrite: false,
      uniforms: {
        uTop: { value: new THREE.Color("#3e7fd2") },
        uHor: { value: new THREE.Color("#b8d0ec") },
      },
      vertexShader: `varying vec3 vPos; void main() { vPos = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
      fragmentShader: `uniform vec3 uTop; uniform vec3 uHor; varying vec3 vPos;
        void main() {
          float h = clamp(normalize(vPos).y * 1.8, 0.0, 1.0);
          gl_FragColor = vec4(mix(uHor, uTop, pow(h, 0.75)), 1.0);
        }`,
    });
    const sky = new THREE.Mesh(new THREE.SphereGeometry(500, 16, 12), this.skyMat);
    this.root.add(sky);
  }

  update(id: number, f: number, cam: THREE.PerspectiveCamera, scene: THREE.Scene): THREE.Vector3 {
    const shot = SHOTS[id - 1];
    const preset = shot.light;
    const L = LIGHTS[preset];
    const K = LOOK[preset];

    const c = camAt(id, f);
    cam.position.set(c.pos[0], c.pos[1], c.pos[2]);
    cam.fov = c.fov;
    cam.updateProjectionMatrix();
    cam.lookAt(c.look[0], c.look[1], c.look[2]);
    cam.rotateZ(c.roll);

    // Sun & sky
    const dir = sunDir(preset, cam.position, new THREE.Vector3(...c.look));
    this.sun.position.set(c.look[0] + dir.x * 30, c.look[1] + dir.y * 30, c.look[2] + dir.z * 30);
    this.sun.target.position.set(c.look[0], c.look[1], c.look[2]);
    this.skyMat.uniforms.uTop.value.set(K.skyTop);
    this.skyMat.uniforms.uHor.value.set(K.skyHor);
    scene.fog = new THREE.Fog(K.fog, K.fogNear, K.fogFar);

    setShade({
      sun: dir,
      lit: L.lit,
      shade: L.shade,
      lift: L.lift,
      fogColor: new THREE.Color(K.fog),
      fogNear: K.fogNear,
      fogFar: K.fogFar,
    });
    setCardSun(dir, preset === "golden");

    this.cast.update(id, f, c.pos);
    return new THREE.Vector3(c.look[0], c.look[1], c.look[2]);
  }
}
