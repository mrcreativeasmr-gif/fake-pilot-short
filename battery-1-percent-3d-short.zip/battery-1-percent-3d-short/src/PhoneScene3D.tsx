import React, { useMemo } from "react";
import { useCurrentFrame, useVideoConfig } from "remotion";
import * as THREE from "three";

interface PhoneSceneProps {
  who: "battery" | "owner";
  pairIdx: number;
  activeIdx: number;
  isDead: boolean;
  flicker: boolean;
  blindLight: boolean;
  flashlightOn: boolean;
}

export const PhoneScene3D: React.FC<PhoneSceneProps> = ({
  who,
  activeIdx,
  isDead,
  flicker,
  blindLight,
  flashlightOn,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = frame / fps;

  // Dynamic camera choreography synced to speaker & action
  const camTarget = useMemo(() => {
    if (isDead) return { x: 0.4, y: 0.2, z: 6.2, rx: -0.1, ry: 0.25 };
    if (activeIdx === 4) return { x: -0.3, y: 0.5, z: 4.8, rx: 0.12, ry: -0.22 };
    if (activeIdx === 13) return { x: 0.0, y: 0.3, z: 4.2, rx: 0.0, ry: 0.0 };
    if (who === "battery") {
      return { x: Math.sin(t * 1.4) * 0.25, y: 0.1, z: 4.9, rx: 0.05, ry: -0.18 + Math.sin(t * 0.9) * 0.12 };
    }
    return { x: Math.cos(t * 1.1) * 0.35, y: 0.35, z: 5.8, rx: -0.08, ry: 0.28 + Math.sin(t * 0.7) * 0.1 };
  }, [who, activeIdx, isDead, t]);

  // Subtle tremble when battery is panicking
  const trembleX = !isDead && who === "battery" ? Math.sin(t * 36) * 0.03 : 0;
  const trembleY = !isDead && who === "battery" ? Math.cos(t * 28) * 0.02 : 0;

  // Glowing floating particles
  const particles = useMemo(() => {
    const pts: Array<{ pos: [number, number, number]; speed: number; size: number }> = [];
    for (let i = 0; i < 28; i++) {
      pts.push({
        pos: [
          ((i * 1.73) % 7) - 3.5,
          ((i * 2.41) % 10) - 5.0,
          ((i * 1.19) % 4) - 3.0,
        ],
        speed: 0.4 + (i % 5) * 0.15,
        size: 0.035 + (i % 3) * 0.02,
      });
    }
    return pts;
  }, []);

  const screenColor = isDead
    ? "#090b10"
    : flicker
    ? "#111624"
    : blindLight
    ? "#ffffff"
    : who === "battery"
    ? "#1c2842"
    : "#162038";

  const redPulse = isDead ? 0.1 : 1.2 + Math.sin(t * 8) * 0.7;

  return (
    <>
      <color attach="background" args={[isDead ? "#05070c" : blindLight ? "#22293e" : "#0b1020"]} />
      <fog attach="fog" args={[isDead ? "#05070c" : "#0b1020", 6, 16]} />

      <ambientLight intensity={isDead ? 0.25 : blindLight ? 1.8 : 0.75} />
      <directionalLight position={[4, 6, 5]} intensity={isDead ? 0.4 : 1.6} color="#a8d0ff" />
      <pointLight
        position={[-2.5, -1, 3]}
        intensity={isDead ? 0.2 : 2.5}
        color={who === "battery" ? "#ff3844" : "#3b82f6"}
      />

      {/* Floating 3D Smartphone Assembly */}
      <group
        position={[trembleX, trembleY + Math.sin(t * 1.8) * 0.08, 5.2 - camTarget.z]}
        rotation={[camTarget.rx, camTarget.ry, Math.sin(t * 1.2) * 0.04]}
      >
        {/* Sleek Metallic Phone Chassis */}
        <mesh>
          <boxGeometry args={[2.1, 4.1, 0.22]} />
          <meshStandardMaterial color="#1f2536" metalness={0.8} roughness={0.22} />
        </mesh>

        {/* Camera Bump on Back */}
        <mesh position={[-0.55, 1.45, -0.14]}>
          <boxGeometry args={[0.68, 0.68, 0.08]} />
          <meshStandardMaterial color="#141824" metalness={0.85} roughness={0.2} />
        </mesh>

        {/* Glowing Front Screen */}
        <mesh position={[0, 0, 0.115]}>
          <planeGeometry args={[1.9, 3.85]} />
          <meshStandardMaterial
            color={screenColor}
            emissive={isDead ? "#000000" : blindLight ? "#fffbe0" : "#1a2a4a"}
            emissiveIntensity={blindLight ? 1.6 : 0.6}
            roughness={0.15}
          />
        </mesh>

        {/* 3D Floating Battery Core inside/above Screen */}
        <group position={[0, 0.05, 0.28]}>
          {/* Battery Terminal Nub */}
          <mesh position={[0, 0.92, 0]}>
            <boxGeometry args={[0.38, 0.14, 0.14]} />
            <meshStandardMaterial color="#cbd5e1" metalness={0.6} roughness={0.3} />
          </mesh>

          {/* Outer Glass Battery Shell */}
          <mesh>
            <boxGeometry args={[0.96, 1.68, 0.18]} />
            <meshStandardMaterial
              color="#94a3b8"
              transparent
              opacity={0.26}
              roughness={0.1}
              metalness={0.2}
            />
          </mesh>

          {/* Glowing 1% Red Energy Sliver at Bottom */}
          {!isDead && (
            <mesh position={[0, -0.68, 0.02]}>
              <boxGeometry args={[0.84, 0.24, 0.14]} />
              <meshStandardMaterial
                color="#ff3844"
                emissive="#ff2a38"
                emissiveIntensity={redPulse}
              />
            </mesh>
          )}
        </group>

        {/* Volumetric Flashlight Cone when Flashlight is ON */}
        {flashlightOn && !isDead && (
          <mesh position={[0, 1.2, 2.2]} rotation={[Math.PI / 2, 0, 0]}>
            <coneGeometry args={[1.8, 4.5, 24, 1, true]} />
            <meshBasicMaterial
              color="#fff6b8"
              transparent
              opacity={0.24}
              side={THREE.DoubleSide}
              depthWrite={false}
            />
          </mesh>
        )}
      </group>

      {/* Ambient Floating 3D Particles */}
      {!isDead &&
        particles.map((p, i) => {
          const py = ((p.pos[1] + t * p.speed + 5) % 10) - 5;
          return (
            <mesh key={i} position={[p.pos[0], py, p.pos[2]]}>
              <sphereGeometry args={[p.size, 8, 8]} />
              <meshBasicMaterial
                color={who === "battery" ? "#ff5566" : "#60a5fa"}
                transparent
                opacity={0.55}
              />
            </mesh>
          );
        })}
    </>
  );
};
