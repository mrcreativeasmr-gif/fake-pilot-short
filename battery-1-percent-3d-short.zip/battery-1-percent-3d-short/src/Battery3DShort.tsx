import React from "react";
import {
  AbsoluteFill,
  Audio,
  interpolate,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import { ThreeCanvas } from "@remotion/three";
import { PhoneScene3D } from "./PhoneScene3D";
import timeline from "./timeline.json";

interface Turn {
  idx: number;
  who: "battery" | "owner";
  s: number;
  e: number;
  text: string;
}

const TURNS = timeline.turns as Turn[];
const DIE_T = timeline.die_t;

export const Battery3DShort: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps, width, height } = useVideoConfig();
  const t = frame / fps;

  let activeIdx = TURNS.findIndex((tr) => t >= tr.s && t <= tr.e + 0.1);
  if (activeIdx < 0) {
    activeIdx = t < TURNS[0].s ? 0 : TURNS.length - 1;
  }

  const cur = TURNS[activeIdx];
  const dtTurn = Math.max(0, t - cur.s);
  const pop = spring({
    frame: Math.round(dtTurn * fps),
    fps,
    config: { damping: 14, stiffness: 180 },
  });

  const isDead = t >= DIE_T;
  const flicker = cur.idx === 7 && frame % 6 < 2;
  const blindLight = activeIdx === 4;
  const flashlightOn = cur.idx >= 8 && !isDead;

  // Brightness slider progress on Turn 4
  const brightFill =
    activeIdx === 4
      ? interpolate(dtTurn, [0, 1.4], [40, 100], { extrapolateRight: "clamp" })
      : cur.idx >= 2
      ? 100
      : 40;

  const isBattery = cur.who === "battery";
  const speakerColor = isBattery ? "#ff3b47" : "#38bdf8";

  return (
    <AbsoluteFill style={{ backgroundColor: "#0b1020", fontFamily: "system-ui, -apple-system, sans-serif" }}>
      <Audio src={staticFile("dialogue_mix.wav")} />

      {/* 3D Three.js Canvas */}
      <ThreeCanvas width={width} height={height} camera={{ fov: 42, position: [0, 0, 5.5] }}>
        <PhoneScene3D
          who={cur.who}
          pairIdx={cur.idx}
          activeIdx={activeIdx}
          isDead={isDead}
          flicker={flicker}
          blindLight={blindLight}
          flashlightOn={flashlightOn}
        />
      </ThreeCanvas>

      {/* Top Status Bar Pill */}
      <div
        style={{
          position: "absolute",
          top: 90,
          left: 0,
          right: 0,
          display: "flex",
          justifyContent: "center",
          gap: 16,
        }}
      >
        <div
          style={{
            background: "rgba(15, 23, 42, 0.85)",
            border: `3px solid ${isDead ? "#ef4444" : "#ff3b47"}`,
            borderRadius: 999,
            padding: "12px 28px",
            display: "flex",
            alignItems: "center",
            gap: 12,
            boxShadow: "0 12px 32px rgba(0,0,0,0.45)",
          }}
        >
          <span style={{ fontSize: 30, fontWeight: 900, color: isDead ? "#ef4444" : "#ff4d5a" }}>
            {isDead ? "🪫 0% DEAD" : "🔋 1% CRITICAL"}
          </span>
        </div>
      </div>

      {/* Brightness Slider UI on Pair 2+ */}
      {cur.idx >= 2 && !isDead && (
        <div
          style={{
            position: "absolute",
            top: 195,
            left: "50%",
            transform: `translateX(-50%) scale(${activeIdx === 4 ? pop : 1})`,
            width: 520,
            background: "rgba(15, 23, 42, 0.88)",
            borderRadius: 24,
            padding: "16px 24px",
            border: "2px solid rgba(255,255,255,0.18)",
          }}
        >
          <div style={{ display: "flex", justifyContent: "space-between", color: "#fff", fontSize: 24, fontWeight: 700, marginBottom: 10 }}>
            <span>☀️ BRIGHTNESS</span>
            <span style={{ color: "#facc15" }}>{Math.round(brightFill)}%</span>
          </div>
          <div style={{ width: "100%", height: 18, background: "#334155", borderRadius: 999, overflow: "hidden" }}>
            <div style={{ width: `${brightFill}%`, height: "100%", background: "linear-gradient(90deg, #f59e0b, #fde047)" }} />
          </div>
        </div>
      )}

      {/* Dialogue-Synced UI Popups */}
      {activeIdx === 6 && (
        <div
          style={{
            position: "absolute",
            top: 340,
            left: "50%",
            transform: `translateX(-50%) scale(${pop})`,
            background: "#dc2626",
            color: "#fff",
            padding: "16px 34px",
            borderRadius: 20,
            fontSize: 32,
            fontWeight: 900,
            boxShadow: "0 16px 36px rgba(220,38,38,0.45)",
          }}
        >
          ▶ YOUTUBE • 40:00 VIDEO
        </div>
      )}

      {activeIdx === 7 && (
        <div
          style={{
            position: "absolute",
            top: 340,
            left: "50%",
            transform: `translateX(-50%) scale(${pop})`,
            background: "#ef4444",
            color: "#fff",
            padding: "16px 36px",
            borderRadius: 999,
            fontSize: 34,
            fontWeight: 900,
          }}
        >
          ⚡ 2x SPEED ON
        </div>
      )}

      {(activeIdx === 11 || activeIdx === 12) && (
        <div
          style={{
            position: "absolute",
            top: 340,
            left: "50%",
            transform: `translateX(-50%) scale(${pop})`,
            background: "#facc15",
            color: "#0f172a",
            padding: "16px 34px",
            borderRadius: 20,
            fontSize: 30,
            fontWeight: 900,
          }}
        >
          💬 142 COMMENTS • TYPING...
        </div>
      )}

      {(activeIdx === 17 || activeIdx === 18) && !isDead && (
        <div
          style={{
            position: "absolute",
            top: 340,
            left: "50%",
            transform: `translateX(-50%) scale(${pop})`,
            background: "#fef08a",
            color: "#0f172a",
            padding: "16px 36px",
            borderRadius: 20,
            fontSize: 32,
            fontWeight: 900,
          }}
        >
          🔦 FLASHLIGHT: ON
        </div>
      )}

      {/* Kinetic Typography Subtitles */}
      {(t < DIE_T || t >= DIE_T + 0.75) && (
        <div
          style={{
            position: "absolute",
            bottom: 240,
            left: 60,
            right: 60,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            transform: `scale(${0.92 + 0.08 * pop})`,
          }}
        >
          <div
            style={{
              background: speakerColor,
              color: "#fff",
              fontSize: 22,
              fontWeight: 900,
              letterSpacing: 1.5,
              padding: "6px 20px",
              borderRadius: 999,
              marginBottom: 14,
              textTransform: "uppercase",
            }}
          >
            {isBattery ? "1% Battery" : "Owner"}
          </div>
          <div
            style={{
              color: "#fde047",
              fontSize: 48,
              fontWeight: 900,
              textAlign: "center",
              lineHeight: 1.2,
              textShadow: "0 4px 0 #0f172a, 0 8px 24px rgba(0,0,0,0.85)",
              WebkitTextStroke: "2px #0f172a",
            }}
          >
            {cur.text}
          </div>
        </div>
      )}
    </AbsoluteFill>
  );
};
