import React from "react";
import { Composition } from "remotion";
import { Battery3DShort } from "./Battery3DShort";
import timeline from "./timeline.json";

const FPS = 24;
const DURATION_FRAMES = Math.ceil(timeline.duration * FPS);

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="Battery3DShort"
      component={Battery3DShort}
      durationInFrames={DURATION_FRAMES}
      fps={FPS}
      width={1080}
      height={1920}
    />
  );
};
